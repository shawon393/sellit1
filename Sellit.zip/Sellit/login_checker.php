<?php
include_once "connection.php";
$email = $_GET['email'];
$pass = $_GET['pass'];

$sql = "SELECT * FROM users WHERE email = '$email' AND password = '$pass' ";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    session_start();
    $_SESSION['email'] = $email;
    header("Location:index.php");
} else {
    header("Location:login.php?error=1");
}