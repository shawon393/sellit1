<?php
include_once "connection.php";
include_once "session.php";

$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['pass_1'];

$sql = "UPDATE users SET name='$name',email='$email',phone='$phone',password='$password' WHERE email = '$email' ";

if (mysqli_query($conn, $sql)) {
    header("Location:account.php");
} else {
    echo "failed";
}