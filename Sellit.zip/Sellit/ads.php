<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <title>All Ads</title>
</head>

<body>

    <style>

    </style>


    <nav class="ui-nav">
        <div class="container">
            <div class="ui-logo"><a href="index.php">Sellit</a></div>
            <ul class="ui-nav-list">
                <li class="ui-nav-item  force-show-label browse-ads gtm-hamburger-ads"><a href="ads.php" rel=""
                        target=""><span class="hide-for-inactive">All ads</span></a></li>
            </ul>
            <ul class="ui-nav-list is-opposite">
                <li class="ui-nav-item   nav-dashboard"><a href="/en/my/dashboard" rel="nofollow" target=""><svg
                            class="ui-icon i-user">
                            <use xlink:href="#i-user"></use>
                        </svg><span class="hide-for-inactive">My account</span></a></li>
                <?php
                session_start();
                if (!isset($_SESSION['email'])) {
                    echo '<li class="ui-nav-item   nav-login"><a href="login.php" rel="nofollow" target="">';
                    echo '<svg class="ui-icon i-user">';
                    echo '<use xlink:href="#i-user"></use>';
                    echo '</svg><span class="hide-for-inactive">Log in</span></a></li>';
                }
                if (isset($_SESSION['email'])) {
                    echo '<li class="ui-nav-item   nav-login"><a href="account.php" rel="nofollow" target="">';
                    echo '<svg class="ui-icon i-user">';
                    echo '<use xlink:href="#i-user"></use>';
                    echo '</svg><span class="hide-for-inactive">My Account</span></a></li>';

                    echo '<li class="ui-nav-item   nav-login"><a href="logout.php" rel="nofollow" target="">';
                    echo '<svg class="ui-icon i-user">';
                    echo '<use xlink:href="#i-user"></use>';
                    echo '</svg><span class="hide-for-inactive">Log out</span></a></li>';
                }
                ?>


                <li><a class="ui-btn is-important btn-post" href="post.php" rel="nofollow"><span
                            class="h4 t-bold btn-post">POST YOUR AD</span></a></li>
            </ul>
        </div>
    </nav>

    <div class="container" style="margin-top: 100px;">
        <?php
        include_once "connection.php";
        if ($_REQUEST) {
            $catagory = $_GET['catagory'];
            $sql = "SELECT * FROM ads WHERE product_catagory = '$catagory' ORDER BY id DESC";
        } else {
            $sql = "SELECT * FROM ads ORDER BY id DESC";
        }

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            // output data of each row
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<a href="ad.php?id=' . $row['id'] . ' " style="text-decoration: inherit;color: inherit;"> ';
                echo '    <div class="row"> ';
                echo '        <div class="col-md-6"> ';
                echo '            <div class="float-right"> ';
                echo '                <img src="images/' . $row['image'] . '" height="150px"> ';

                echo '            </div> ';
                echo '        </div> ';
                echo '        <div class="col-md-6"> ';
                echo '            <h3>' . $row['product_name'] . '</h3> ';
                echo '            <h4>' . $row['location'] . '</h4> ';
                echo '            <h5 style="color: #128e73;">' . $row['price'] . ' Taka</h5> ';
                echo '            <h6>' . $row['product_catagory'] . '</h6> ';
                echo '        </div> ';
                echo '    </div> ';
                echo '    <hr> ';
                echo '</a> ';
            }
        } else {
            echo "<h3>Not Product for sell!</h3>";
        }
        ?>
    </div>


</body>

</html>