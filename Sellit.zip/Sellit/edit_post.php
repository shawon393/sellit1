<?php
include_once "connection.php";
include_once "session.php";

$id = $_POST['id'];
$name = $_POST['name'];
$location = $_POST['location'];
$price = $_POST['price'];
$description = $_POST['description'];

$sql = "UPDATE ads SET product_name='$name',location='$location',price='$price',details='$description' WHERE id = '$id' ";

if (mysqli_query($conn, $sql)) {
    header("Location:ad.php?id=" . $id);
} else {
    echo "failed";
}