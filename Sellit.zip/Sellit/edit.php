<?php
include_once "session.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <title>Edit Your Ad</title>
</head>

<body>

    <style>

    </style>


    <nav class="ui-nav">
        <div class="container">
            <div class="ui-logo"><a href="index.php">Sellit</a></div>
            <ul class="ui-nav-list">
                <li class="ui-nav-item  force-show-label browse-ads gtm-hamburger-ads"><a href="ads.php" rel=""
                        target=""><span class="hide-for-inactive">All ads</span></a></li>
            </ul>
            <ul class="ui-nav-list is-opposite">
                <li class="ui-nav-item   nav-login"><a href="account.php" rel="nofollow" target=""><svg
                            class="ui-icon i-user">
                            <use xlink:href="#i-user"></use>
                        </svg><span class="hide-for-inactive">My account</span></a></li>
                <li class="ui-nav-item   nav-login"><a href="logout.php" rel="nofollow" target=""><svg
                            class="ui-icon i-user">
                            <use xlink:href="#i-user"></use>
                        </svg><span class="hide-for-inactive">Logout</span></a></li>
            </ul>
        </div>
    </nav>

    <?php
    include_once "connection.php";

    $id = $_GET['id'];
    $sql = "SELECT * FROM ads WHERE id = '$id'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        // output data of each row
        while ($row = mysqli_fetch_assoc($result)) {
            echo ' <div class="container" style="margin-top: 20px;"> ';
            echo '     <h3>Edit Your Ad</h3> ';
            echo '     <form class="" action="edit_post.php" method="POST"> ';
            echo '         <input type="hidden" class="form-control" name="id" value="' . $id . '" required> ';
            echo '         <div class="form-group"> ';
            echo '             <label>Product Name</label> ';
            echo '             <input type="text" class="form-control" name="name" value="' . $row['product_name'] . '" required> ';
            echo '         </div> ';
            echo '         <div class="form-group"> ';
            echo '             <label>Location</label> ';
            echo '             <input type="text" class="form-control" name="location" placeholder="Your Location" value="' . $row['location'] . '" required> ';
            echo '         </div> ';
            echo '         <div class="form-group"> ';
            echo '             <label>Price</label> ';
            echo '             <input type="number" class="form-control" name="price" placeholder="Price" value="' . $row['price'] . '" required> ';
            echo '         </div> ';
            echo '         <div class="form-group"> ';
            echo '             <label>Description</label> ';
            echo '             <textarea type="text" class="form-control" name="description" placeholder="Description" ';
            echo '                  required>' . $row['details'] . '</textarea> ';
            echo '         </div> ';
            echo '         <button type="submit" class="btn btn-primary" style="background-color: #128e73;">Update</button> ';
            echo '     </form> ';
            echo ' </div> ';
        }
    }

    ?>


</body>

</html>