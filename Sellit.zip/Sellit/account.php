<?php
include_once "session.php";
include_once "connection.php";

$email = $_SESSION['email'];

$sql = "SELECT * FROM users WHERE email = '$email' ";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while ($row = mysqli_fetch_assoc($result)) {
        $u_id = $row['id'];
        $name = $row['name'];
        $phone = $row['phone'];
        $password = $row['password'];
    }
} else {
    echo "0 results";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <script src="vendor/bootstrap/js/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <title>Your Account</title>
</head>

<body>

    <style>

    </style>


    <nav class="ui-nav">
        <div class="container">
            <div class="ui-logo"><a href="index.php">Sellit</a></div>
            <ul class="ui-nav-list">
                <li class="ui-nav-item  force-show-label browse-ads gtm-hamburger-ads"><a href="ads.php" rel=""
                        target=""><span class="hide-for-inactive">All ads</span></a></li>
            </ul>
            <ul class="ui-nav-list is-opposite">
                <li class="ui-nav-item   nav-login"><a href="account.php" rel="nofollow" target=""><svg
                            class="ui-icon i-user">
                            <use xlink:href="#i-user"></use>
                        </svg><span class="hide-for-inactive">My account</span></a></li>
                <li class="ui-nav-item   nav-login"><a href="logout.php" rel="nofollow" target=""><svg
                            class="ui-icon i-user">
                            <use xlink:href="#i-user"></use>
                        </svg><span class="hide-for-inactive">Logout</span></a></li>
                <li><a class="ui-btn is-important btn-post" href="post.php" rel="nofollow"><span
                            class="h4 t-bold btn-post">POST YOUR AD</span></a></li>
            </ul>
        </div>
    </nav>

    <div class="container" style="margin-top: 100px;">
        <div class="row">
            <div class="col-md-12">
                <center>
                    <h3> <?php echo $name; ?> </h3>
                </center>
                <form class="" action="update_account.php" method="POST">
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" name="name" value="<?php echo $name; ?>"
                            placeholder="Your Name" required>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" class="form-control" name="email" value="<?php echo $email; ?>"
                            placeholder="Email" required>
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="phone" class="form-control" name="phone" value="<?php echo $phone; ?>"
                            placeholder="Email" required>
                    </div>
                    <div class="form-group">
                        <label>Confirm Password</label>
                        <input type="password" class="form-control" name="pass_1" value="<?php echo $password; ?>"
                            placeholder="Confirm Password" required>
                    </div>
                    <div class="form-group">
                        <label>Confirm Password</label>
                        <input type="password" class="form-control" name="pass_2" value="<?php echo $password; ?>"
                            placeholder="Confirm Password" required>
                    </div>
                    <button type="submit" class="btn btn-primary" style="background-color: #128e73;">Update</button>
                </form>


                <center>
                    <h3 style="margin-top: 50px;">Your Ads</h3>
                </center>
                <?php
                if ($_REQUEST) {
                    if ($_GET['code'] == '1') {
                        echo '<div class="alert alert-danger alert-dismissible" role="alert">';
                        echo '    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
                        echo '    <strong>Ad deleted !</strong>';
                        echo '</div>';
                    }
                }
                ?>
                <table class=" table table-striped" style="margin-top: 10px;margin-bottom: 50px;">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Delete</th>
                            <th>Edit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql_new = "SELECT * FROM ads WHERE u_id = '$u_id' ";
                        $result_new = mysqli_query($conn, $sql_new);

                        if (mysqli_num_rows($result_new) > 0) {
                            // output data of each row
                            while ($row = mysqli_fetch_assoc($result_new)) {
                                echo '<tr> ';
                                echo '    <td>' . $row['product_name'] . '</td> ';
                                echo '    <td>' . $row['price'] . '</td> ';
                                echo '    <td><a href="delete.php?id=' . $row['id'] . ' " style="color: white;" class="btn btn-danger">Delete</a></td> ';
                                echo '    <td><a href="edit.php?id=' . $row['id'] . ' " style="color: white;" class="btn btn-success">Edit</a></td> ';
                                echo '</tr> ';
                            }
                        } else {
                            echo '<tr> ';
                            echo '    <td colspan = "3">You do not have any ad!</td> ';
                            echo '</tr> ';
                        }
                        ?>
                    </tbody>
                </table>

            </div>
        </div>


</body>

</html>