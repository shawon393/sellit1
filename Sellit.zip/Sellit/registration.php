<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--===============================================================================================-->
    <link rel="stylesheet" href="css/home.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <title>Registration</title>
</head>

<body>

    <nav class="ui-nav">
        <div class="container">
            <div class="ui-logo"><a href="index.php"></a></div>
            <ul class="ui-nav-list">
                <li class="ui-nav-item  force-show-label browse-ads gtm-hamburger-ads"><a href="ads.php" rel=""
                        target=""><span class="hide-for-inactive">All ads</span></a></li>
            </ul>
            <ul class="ui-nav-list is-opposite">
                <li class="ui-nav-item   nav-dashboard"><a href="/en/my/dashboard" rel="nofollow" target=""><svg
                            class="ui-icon i-user">
                            <use xlink:href="#i-user"></use>
                        </svg><span class="hide-for-inactive">My account</span></a></li>
                <li class="ui-nav-item   nav-login"><a href="login.php" rel="nofollow" target=""><svg
                            class="ui-icon i-user">
                            <use xlink:href="#i-user"></use>
                        </svg><span class="hide-for-inactive">Log in</span></a></li>
            </ul>
        </div>
    </nav>




    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100 p-t-50 p-b-90">
                <form action="cont_register.php" method="POST" class="login100-form validate-form flex-sb flex-w">


                    <span class="login100-form-title p-b-51">
                        Registration
                    </span>

                    <?php
                    if ($_REQUEST) {
                        if ($_GET['error'] == '1') {
                            echo '<div class="alert alert-danger" role="alert">';
                            echo '    Passwords did not match !';
                            echo '</div>';
                        } else if ($_GET['error'] == '2') {
                            echo '<div class="alert alert-danger" role="alert">';
                            echo '    Email already taken !';
                            echo '</div>';
                        } else {
                            echo '<div class="alert alert-danger" role="alert">';
                            echo '    Opps ,Server refused to let you in!';
                            echo '</div>';
                        }
                    }
                    ?>

                    <div class="wrap-input100 validate-input m-b-16" data-validate="Username is required">
                        <input class="input100" type="text" name="name" placeholder="Name" required>
                        <span class="focus-input100"></span>
                    </div>

                    <div class="wrap-input100 validate-input m-b-16" data-validate="Username is required">
                        <input class="input100" type="email" name="email" placeholder="Email" required>
                        <span class="focus-input100"></span>
                    </div>

                    <div class="wrap-input100 validate-input m-b-16" data-validate="Username is required">
                        <input class="input100" type="text" name="phone" placeholder="Phone Number" required>
                        <span class="focus-input100"></span>
                    </div>


                    <div class="wrap-input100 validate-input m-b-16" data-validate="Password is required">
                        <input class="input100" type="password" name="pass_1" placeholder="Password" required>
                        <span class="focus-input100"></span>
                    </div>

                    <div class="wrap-input100 validate-input m-b-16" data-validate="Password is required">
                        <input class="input100" type="password" name="pass_2" placeholder="Confirm Password">
                        <span class="focus-input100"></span>
                    </div>

                    <div class="flex-sb-m w-full p-t-3 p-b-24">

                        <div>
                            <a href="login.php" class="txt1">
                                Login
                            </a>
                        </div>
                    </div>

                    <div class="container-login100-form-btn m-t-17">
                        <button class="login100-form-btn" style="background-color: #128e73;">
                            Register
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>



</body>

</html>