<?php
include_once "connection.php";
$id = $_GET['id'];

$sql = "SELECT * FROM ads WHERE id = '$id'";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $file = "images/" . $row['image'];
        if (unlink($file)) {
            $sql_new = "DELETE FROM ads WHERE id = $id";
            mysqli_query($conn, $sql_new);
            header("Location:account.php?code=1");
        } else {
            echo "Opps! Error!!!";
        }
    }
}