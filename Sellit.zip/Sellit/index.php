<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/home.css">
    <title>Sellit</title>
</head>

<body>

    <style>

    </style>


    <nav class="ui-nav">
        <div class="container">
            <div class="ui-logo"><a href="index.php">Sellit</a></div>
            <ul class="ui-nav-list">
                <li class="ui-nav-item  force-show-label browse-ads gtm-hamburger-ads"><a href="ads.php" rel=""
                        target=""><span class="hide-for-inactive">All ads</span></a></li>
            </ul>
            <ul class="ui-nav-list is-opposite">
                <li class="ui-nav-item   nav-dashboard"><a href="/en/my/dashboard" rel="nofollow" target=""><svg
                            class="ui-icon i-user">
                            <use xlink:href="#i-user"></use>
                        </svg><span class="hide-for-inactive">My account</span></a></li>
                <?php
                session_start();
                if (!isset($_SESSION['email'])) {
                    echo '<li class="ui-nav-item   nav-login"><a href="login.php" rel="nofollow" target="">';
                    echo '<svg class="ui-icon i-user">';
                    echo '<use xlink:href="#i-user"></use>';
                    echo '</svg><span class="hide-for-inactive">Log in</span></a></li>';
                }
                if (isset($_SESSION['email'])) {
                    echo '<li class="ui-nav-item   nav-login"><a href="account.php" rel="nofollow" target="">';
                    echo '<svg class="ui-icon i-user">';
                    echo '<use xlink:href="#i-user"></use>';
                    echo '</svg><span class="hide-for-inactive">My Account</span></a></li>';

                    echo '<li class="ui-nav-item   nav-login"><a href="logout.php" rel="nofollow" target="">';
                    echo '<svg class="ui-icon i-user">';
                    echo '<use xlink:href="#i-user"></use>';
                    echo '</svg><span class="hide-for-inactive">Log out</span></a></li>';
                }
                ?>


                <li><a class="ui-btn is-important btn-post" href="post.php" rel="nofollow"><span
                            class="h4 t-bold btn-post">POST YOUR AD</span></a></li>
            </ul>
        </div>
    </nav>


    <div class="row" style="margin-bottom: 30px;">
        <div class="col-4">

        </div>
        <div class="col-4">
            <h1 class="t-bold">Welcome to Sellit - new marketplace in Bangladesh!</h1>
            <p>Buy and sell everything from used cars to mobile phones and computers <strong>in Bangladesh</strong>!</p>
        </div>
        <div class="col-4">

        </div>
    </div>


    <div class="container">
        <div class="ui-panel is-rounded">
            <div class="ui-panel-content ui-panel-block">
                <div class="home-categories">
                    <div class="row lg-g">
                        <div class="col-12 lg-3">
                            <h4 class="menu-item-header"><a href="ads.php?catagory=Mobiles" class="t-bold"><span
                                        class="ui-sprite categories-36 mobiles"></span><span>Mobiles</span></a></h4>
                            <p class="info t-small">Buy and sell new and used mobiles, SIM cards and other mobile
                                accessories in
                                Bangladesh. Choose from top brands including Apple, OnePlus, Xiaomi and Nokia.</p>
                        </div>
                        <div class="col-12 lg-3">
                            <h4 class="menu-item-header"><a href="ads.php?catagory=Electronics" class="t-bold"><span
                                        class="ui-sprite categories-36 electronics"></span><span>Electronics</span></a>
                            </h4>
                            <p class="info t-small">Find great deals for used electronics in Bangladesh including mobile
                                phones,
                                computers, laptops, TVs, cameras and much more.</p>
                        </div>
                        <div class="col-12 lg-3">
                            <h4 class="menu-item-header"><a href="ads.php?catagory=Home" class="t-bold"><span
                                        class="ui-sprite categories-36 home"></span><span>Home</span></a>
                            </h4>
                            <p class="info t-small">Buy and sell new and used home appliances including furniture,
                                kitchen
                                items, gardening products and other items for your garden.</p>
                        </div>
                        <div class="col-12 lg-3">
                            <h4 class="menu-item-header"><a href="ads.php?catagory=Vehicles" class="t-bold"><span
                                        class="ui-sprite categories-36 vehicles"></span><span>Vehicles</span></a></h4>
                            <p class="info t-small">Buy and sell used cars, motorbikes and other vehicles in Bangladesh.
                                Choose
                                from top brands including Toyota, Nissan, Honda and Suzuki.</p>
                        </div>
                    </div>
                    <div class="row lg-g">
                        <div class="col-12 lg-3">
                            <h4 class="menu-item-header"><a href="ads.php?catagory=Property" class="t-bold"><span
                                        class="ui-sprite categories-36 property"></span><span>Property</span></a></h4>
                            <p class="info t-small">View listings for property in Bangladesh. Find the cheapest rates
                                for
                                apartments, commercial and residential properties, as well as for land and plots.</p>
                        </div>
                        <div class="col-12 lg-3">
                            <h4 class="menu-item-header"><a href="ads.php?catagory=Pets" class="t-bold"><span
                                        class="ui-sprite categories-36 animals"></span><span>Pets</span></a>
                            </h4>
                            <p class="info t-small">Search from the widest variety of pets in Bangladesh. Select from
                                dogs,
                                puppies, cats, kittens, birds and other domesticated animals.</p>
                        </div>
                        <div class="col-12 lg-3">
                            <h4 class="menu-item-header"><a href="ads.php?catagory=Fashion" class="t-bold"><span
                                        class="ui-sprite categories-36 fashion"></span><span>Fashion</span></a>
                            </h4>
                            <p class="info t-small">Buy and sell clothing, garments, shoes and other personal items
                                including
                                handbags, perfumes etc.</p>
                        </div>
                        <div class="col-12 lg-3">
                            <h4 class="menu-item-header"><a href="ads.php?catagory=Essentials" class="t-bold"><span
                                        class="ui-sprite categories-36 essentials"></span><span>Essentials</span></a>
                            </h4>
                            <p class="info t-small">Find daily essential products, including groceries, healthcare
                                products,
                                household items, fruits &amp; vegetables, meat &amp; seafood and baby products near you.
                            </p>
                        </div>
                    </div>
                    <div class="row lg-g">
                        <div class="col-12 lg-3">
                            <h4 class="menu-item-header"><a href="ads.php?catagory=Sports" class="t-bold"><span
                                        class="ui-sprite categories-36 hobby"></span><span>Sports</span></a>
                            </h4>
                            <p class="info t-small">Buy and sell used musical instruments, sports gear and accessories,
                                art
                                and
                                collectibles and items for kids here.</p>
                        </div>
                        <div class="col-12 lg-3">
                            <h4 class="menu-item-header"><a href="ads.php?catagory=Education" class="t-bold"><span
                                        class="ui-sprite categories-36 education"></span><span>Education</span></a></h4>
                            <p class="info t-small">Buy and sell books and magazines, find tuition, classes and other
                                educational resources in Bangladesh.</p>
                        </div>
                        <div class="col-12 lg-3">
                            <h4 class="menu-item-header"><a href="ads.php?catagory=Business" class="t-bold"><span
                                        class="ui-sprite categories-36 business"></span><span>Business</span></a>
                            </h4>
                            <p class="info t-small">This is where businesses in Bangladesh trade, numerous business and
                                industry
                                services offered to trade and consumers.</p>
                        </div>
                        <div class="col-12 lg-3">
                            <h4 class="menu-item-header"><a href="ads.php?catagory=Agriculture" class="t-bold"><span
                                        class="ui-sprite categories-36 food"></span><span>Agriculture</span></a></h4>
                            <p class="info t-small">Find agricultural products, including fresh crop seeds, plants and
                                fertilizers in Bangladesh.</p>
                        </div>
                    </div>
                    <div class="row lg-g">
                        <div class="col-12 lg-3">
                            <h4 class="menu-item-header"><a href="ads.php?catagory=Services" class="t-bold"><span
                                        class="ui-sprite categories-36 services"></span><span>Services</span></a></h4>
                            <p class="info t-small">Browse through a range of service offerings to businesses and
                                consumers
                                alike.</p>
                        </div>
                        <div class="col-12 lg-3">
                            <h4 class="menu-item-header"><a href="ads.php?catagory=Jobs" class="t-bold"><span
                                        class="ui-sprite categories-36 jobs"></span><span>Jobs</span></a></h4>
                            <p class="info t-small">Post and apply for jobs and career opportunities in Bangladesh.
                                Search
                                for
                                job vacancies in your city.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="post-cta t-center">
        <p class="h1">Do you have something to sell?</p>
        <p class="h3">Post your ad on Sellit</p>
        <p class="gtm-postad"><svg class="ui-icon i-pointer-l">
                <use xlink:href="#i-pointer-l"></use>
            </svg><a class="ui-btn is-primary gtm-postad" href="post.php" rel="nofollow">Post an ad now!</a><svg
                class="ui-icon i-pointer-r">
                <use xlink:href="#i-pointer-r"></use>
            </svg></p>
    </div>



</body>

</html>