<?php
include_once "connection.php";
include_once "session.php";

$email = $_SESSION['email'];
$sql = "SELECT * FROM users WHERE email = '$email' ";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $u_id = $row['id'];
    }
}

$p_name = $_POST['name'];
$catagory = $_POST['catagory'];
$p_location = $_POST['location'];
$price = $_POST['price'];
$description = $_POST['description'];

$name = $_FILES['file']['name'];
if (!$name == "") {

    $tmp_name =  $_FILES['file']['tmp_name'];

    $location = "images/";
    $uniquename = time() . "-" . rand(1000, 9999) . "-" . $name;

    $new_name = $location . $uniquename;
    if (move_uploaded_file($tmp_name, $new_name)) {
        echo "<br>uploaded";
    } else {
        $uniquename = time() . "-" . rand(1000, 9999) . "-" . $name;
        $new_name = $location . $uniquename;
        if (move_uploaded_file($tmp_name, $new_name)) {
            echo "<br>uploaded ";
        } else {
            $uniquename = '';
            echo "failed, better luck next time";
        }
    }
}

$sql2 = "INSERT INTO ads(u_id, product_name, product_catagory, location, price, details, image) values('$u_id','$p_name','$catagory','$p_location','$price','$description','$uniquename')";

if (mysqli_query($conn, $sql2)) {
    header("Location:ads.php");
} else {
    echo "failed";
}