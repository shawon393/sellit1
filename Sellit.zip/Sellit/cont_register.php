<?php
include_once "connection.php";
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$pass_1 = $_POST['pass_1'];
$pass_2 = $_POST['pass_2'];

$sql = "SELECT * FROM users WHERE email = '$email' ";
$result = mysqli_query($conn, $sql);

if (strcmp($pass_1, $pass_2) != 0) {
    header("Location:registration.php?error=1");
} elseif (mysqli_num_rows($result) > 0) {
    header("Location:registration.php?error=2");
} else {
    $sql = "INSERT INTO users (name,email,phone,password) VALUES ('$name', '$email', '$phone', '$pass_1') ";
    if (mysqli_query($conn, $sql)) {
        header("Location:login.php");
    } else {
        header("Location:registration.php?error=3");
    }
}