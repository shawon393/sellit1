<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--===============================================================================================-->
    <link rel="stylesheet" href="css/home.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <title>Login</title>
</head>

<body>

    <nav class="ui-nav">
        <div class="container">
            <div class="ui-logo"><a href="index.php">Sellit</a></div>
            <ul class="ui-nav-list">
                <li class="ui-nav-item  force-show-label browse-ads gtm-hamburger-ads"><a href="ads.php" rel=""
                        target=""><span class="hide-for-inactive">All ads</span></a></li>
            </ul>
            <ul class="ui-nav-list is-opposite">
                <li class="ui-nav-item   nav-login"><a href="registration.php" rel="nofollow" target=""><svg
                            class="ui-icon i-user">
                            <use xlink:href="#i-user"></use>
                        </svg><span class="hide-for-inactive">Register</span></a></li>
            </ul>
        </div>
    </nav>




    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100 p-t-50 p-b-90">
                <form action="login_checker.php" method="GET" class="login100-form validate-form flex-sb flex-w">
                    <span class="login100-form-title p-b-51">
                        Login
                    </span>


                    <?php
                    if ($_REQUEST) {
                        if ($_GET['error'] == '1') {
                            echo '<div class="alert alert-danger" role="alert">';
                            echo '    Wrong Email or Password !';
                            echo '</div>';
                        }
                    }
                    ?>


                    <div class="wrap-input100 validate-input m-b-16" data-validate="Username is required">
                        <input class="input100" type="text" name="email" placeholder="Email" required>
                        <span class="focus-input100"></span>
                    </div>


                    <div class="wrap-input100 validate-input m-b-16" data-validate="Password is required">
                        <input class="input100" type="password" name="pass" placeholder="Password">
                        <span class="focus-input100"></span>
                    </div>

                    <div class="flex-sb-m w-full p-t-3 p-b-24">
                        <div class="contact100-form-checkbox">
                            <input class="input-checkbox100" id="ckb1" type="checkbox" name="remember-me">
                            <label class="label-checkbox100" for="ckb1">
                                Remember me
                            </label>
                        </div>

                        <div>
                            <a href="registration.php" class="txt1">
                                Register
                            </a>
                        </div>
                    </div>

                    <div class="container-login100-form-btn m-t-17">
                        <button class="login100-form-btn" style="background-color: #128e73;">
                            Login
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>



</body>

</html>