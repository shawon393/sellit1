<?php
include_once "session.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <title>Post Your Ad</title>
</head>

<body>

    <style>

    </style>


    <nav class="ui-nav">
        <div class="container">
            <div class="ui-logo"><a href="index.php">Sellit</a></div>
            <ul class="ui-nav-list">
                <li class="ui-nav-item  force-show-label browse-ads gtm-hamburger-ads"><a href="ads.php" rel=""
                        target=""><span class="hide-for-inactive">All ads</span></a></li>
            </ul>
            <ul class="ui-nav-list is-opposite">
                <li class="ui-nav-item   nav-login"><a href="account.php" rel="nofollow" target=""><svg
                            class="ui-icon i-user">
                            <use xlink:href="#i-user"></use>
                        </svg><span class="hide-for-inactive">My account</span></a></li>
                <li class="ui-nav-item   nav-login"><a href="logout.php" rel="nofollow" target=""><svg
                            class="ui-icon i-user">
                            <use xlink:href="#i-user"></use>
                        </svg><span class="hide-for-inactive">Logout</span></a></li>
            </ul>
        </div>
    </nav>


    <div class="container" style="margin-top: 20px;">
        <h3>Post Your Ad</h3>
        <form class="" action="add_post.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label>Product Name</label>
                <input type="text" class="form-control" name="name" placeholder="Product Name" required>
            </div>
            <div class="form-group">
                <label>Location</label>
                <input type="text" class="form-control" name="location" placeholder="Your Location" required>
            </div>
            <div class="form-group">
                <label>Price</label>
                <input type="number" class="form-control" name="price" placeholder="Price" required>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea type="text" class="form-control" name="description" placeholder="Description"
                    required></textarea>
            </div>
            <div class="form-group">
                <label>Image</label>
                <input type="file" class="form-control" name="file" required>
            </div>
            <div class="form-group">
                <label>Product Catagory</label>
                <select class="form-control" name="catagory">
                    <option value="Mobiles">Mobiles</option>
                    <option value="Electronics">Electronics</option>
                    <option value="Home">Home</option>
                    <option value="Vehicles">Vehicles</option>
                    <option value="Property">Property</option>
                    <option value="Pets">Pets</option>
                    <option value="Fashion">Fashion</option>
                    <option value="Essentials">Essentials</option>
                    <option value="Education">Education</option>
                    <option value="Business">Business</option>
                    <option value="Agriculture">Agriculture</option>
                    <option value="Services">Services</option>
                    <option value="Jobs">Jobs</option>

                </select>
            </div>
            <button type="submit" class="btn btn-primary" style="background-color: #128e73;">Post</button>
        </form>
    </div>

</body>

</html>